﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Args
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Give me the names of the employees");

            foreach (string name in args)
            {
                Console.WriteLine("Hey "+ name);
            }
            
        }
    }
}
