﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datetime
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime dateTimePJ = new DateTime(1994, 7, 7);
            DateTime dateTimeLisa = new DateTime(1996, 9, 30);

            Console.WriteLine("My birthday is {0}", dateTimePJ);

            Console.WriteLine(DateTime.Today);
            Console.WriteLine(DateTime.Now);
            Console.WriteLine("This is the day you were born " + dateTimePJ.DayOfWeek);
            Console.WriteLine("This is the day you were born " + dateTimeLisa.DayOfWeek);
            Console.ReadKey();

            Console.WriteLine("Give me your date of birth in this format: yyyy-mm-dd");
            string dateInput = Console.ReadLine();


            DateTime dateTime = new DateTime();

            if (DateTime.TryParse(dateInput , out dateTime)) //Checks if user input is formatted correctly with TryParse
            {
                Console.WriteLine(dateTime);
                TimeSpan daysPassed = DateTime.Now.Subtract(dateTime);
                Console.WriteLine("You have lived for {0} amount of days",daysPassed.Days);
            }
            Console.WriteLine(DateTime.Today.AddDays(105).ToString());

            Console.ReadKey();
        }
        static DateTime GetTomorrow()
        {
            return DateTime.Today.AddDays(1);
        }
    }
}
