﻿namespace DesignPatterns
{
    class Logger
    {
        private static Logger logger;
        private Logger()
        {

        }
        public static Logger GetInstance()
        {
            if (logger == null)
            {
                logger = new Logger();
            }
            return logger;
        }

    }
}
