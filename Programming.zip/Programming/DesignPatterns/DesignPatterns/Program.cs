﻿namespace DesignPatterns
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger obj1 = Logger.GetInstance();

        }
    }
}
