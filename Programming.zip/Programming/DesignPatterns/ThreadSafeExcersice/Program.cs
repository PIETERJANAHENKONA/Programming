﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadSafeExcersice
{
    class Program
    {
        /// <summary>
        /// //Exercice 1: Singleton
        //❑ Create a thread safe Singleton class for
        //ConsoleManager and add thread safe a method
        //WriteLine (which does a Console.writeline of a
        //string parameter)
        //❑ Create 2 classes that can start a thread
        //– Keeps on prints out all alphabetical chars
        //– The other prints out all numbers up to 100
        //– Add a Start and Pause to both classes
        //❑ In Main
        //– Create 2 objects from those 2 classes
        //– Run start their threads
        //– Let it run for 5 seconds
        //– Stop the threads and end the application
        //– All console output from main also gets written via the
        //ConsoleManager

        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            SafeSingleton safeSingleton = SafeSingleton.GetSafeSingleton;
            SafeSingleton safeSingleton1 = SafeSingleton.GetSafeSingleton;
        }
    }
}
