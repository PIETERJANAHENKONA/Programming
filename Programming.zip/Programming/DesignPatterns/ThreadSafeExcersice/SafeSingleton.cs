﻿namespace ThreadSafeExcersice
{
    public class SafeSingleton
    {
        private static readonly object _Lock = new object(); // Create a lock object

        private static SafeSingleton InstanceOfSingelton;// Private instance of singleton

        private SafeSingleton() 
        {
            Thread1.StartThread();
            Thread2.StartThread();
        }// Create private constructor

        public static SafeSingleton GetSafeSingleton // Public method that returns the instance 
        {
            get
            {
                if (InstanceOfSingelton == null)// Double checking the lock
                {
                    lock (_Lock)// Only one thread can enter at a time
                    {
                        if (InstanceOfSingelton == null)
                        {
                            InstanceOfSingelton = new SafeSingleton();// Creating the instance  

                        }
                    }
                }
                return InstanceOfSingelton;// Creating the instance 


            }

        }

    }
}
