﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace ThreadSafeExcersice
{
    class Thread1
    {
        public static void StartThread()
        {
            int zInt = (int)'z';
            int aInt = (int)'a';
            char[] lowerCaseAlfabet;

            int lengthFromAToZ = zInt - aInt + 1;

            lowerCaseAlfabet = new char[lengthFromAToZ];


            for (int i = 0; i < lengthFromAToZ; i++)
            {

                lowerCaseAlfabet[i] = (char)aInt;
                aInt++;
            }

            Thread aflfabetThread = new Thread(()=> PrintAlfabet(lowerCaseAlfabet));
            aflfabetThread.Start();
            aflfabetThread.Join(5000);
            aflfabetThread.Abort();
        }
        public static void PrintAlfabet(char[] myLowerCaseAlfabet)
        {
            foreach (char character in myLowerCaseAlfabet)
            {
                Console.Write(character + " ");
                Thread.Sleep(300);
            }
        }

    }
}
