﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadSafeExcersice
{
    public class Thread2
    {
        public static void StartThread()
        {
            Thread numThread = new Thread(() => PrintNum());
            numThread.Start();
            numThread.Join(5000);
            numThread.Abort();
        }

        private static void PrintNum()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.Write(i);
                Thread.Sleep(300);
            }
        }
    }
}
