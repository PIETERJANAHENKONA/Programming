﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryOutStuffHere
{
    class Program
    {
        static void Main(string[] args)
        {
            int zInt = (int)'z';
            int aInt = (int)'a';
            char[] lowerCaseAlfabet;

            int lengthFromAToZ = zInt - aInt+1;

            lowerCaseAlfabet = new char[lengthFromAToZ];


            for (int i = 0; i < lengthFromAToZ; i++)
            {

                lowerCaseAlfabet[i] = (char)aInt;
                aInt++;
            }

            foreach (char character in lowerCaseAlfabet)
            {
                Console.Write(character+" ");
            }
        }
    }
}
