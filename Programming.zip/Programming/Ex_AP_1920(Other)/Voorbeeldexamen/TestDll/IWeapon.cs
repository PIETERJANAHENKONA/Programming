﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestDll
{
    public interface IWeapon
    {
        void Shoot();
        void Reload();
    }
}
