﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestDll
{
    public class SDMachineGun: SDWeapon
    {
        public int burst;

        public SDMachineGun() : base("MachineGun", 100, "ratatata")
        {
            burst = 10;
        }

        public override void Shoot()
        {
            SDWeaponsManager w = SDWeaponsManager.GetInstace();
            if (ammo > burst)
            {
                ammo -= burst;
                w.PrintText(sound);
            }
            else
            {
                w.PrintText("CLICKCLICKCLICK");
                Reload();
            }
        }
    }
}
