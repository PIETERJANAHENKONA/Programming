﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestDll
{
    public class SDPistol: SDWeapon
    {
        public SDPistol() : base("Pistol", 12, "pang")
        {

        }
    }
}
