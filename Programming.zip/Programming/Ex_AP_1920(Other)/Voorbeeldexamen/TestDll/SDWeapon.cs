﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestDll
{
    public class SDWeapon: IWeapon
    {
        private string privateName;
        public string name { get { return privateName; } }
        public int ammo;
        public int maxAmmo;
        public string sound;
        private SDWeaponsManager w = SDWeaponsManager.GetInstace();

        public SDWeapon(string inputName, int inputAmmo, string inputSound)
        {
            privateName = inputName;
            ammo = inputAmmo;
            maxAmmo = inputAmmo;
            sound = inputSound;
        }

        public virtual void Shoot()
        {
            if (ammo > 0)
            {
                ammo--;
                w.PrintText(sound);
            }
            else
            {
                w.PrintText("CLICK");
                Reload();
            }
        }

        public void Reload()
        {
            w.PrintText(name + " RELOADING...");
            ammo = maxAmmo;
        }
    }
}
