﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TestDll
{
    public class SDWeaponsManager
    {
        private static readonly object singletonLocker = new object();

        private static readonly object locker = new object();

        private static SDWeaponsManager instance;

        public List<SDWeapon> weaponList = new List<SDWeapon>();

        private int privateWeaponListSize;
        public int weaponListSize { get { return privateWeaponListSize; } }

        public static SDWeaponsManager GetInstace()
        {
            if (instance == null)
            {
                lock (singletonLocker)
                {
                    if (instance == null)
                    {
                        instance = new SDWeaponsManager();
                    }
                }
            }
            return instance;
        }

        private SDWeaponsManager()
        {
            weaponList.Clear();
            privateWeaponListSize = 0;
        }

        public void AddWeapon(SDWeapon weapon)
        {
            weaponList.Add(weapon);
            privateWeaponListSize++;
        }

        public void PrintText(string textToBePrinted)
        {
            lock (locker)
            {
                Console.WriteLine(textToBePrinted);
            }
        }
        
        public SDWeapon GetWeapon(int index)
        {
            try
            {
                return weaponList[index];
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
                throw new ArgumentOutOfRangeException("index parameter is out of range.", e);
            }
        }

    }
}
