﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestDll;

namespace Voorbeeldexamen
{
    class Program
    {
        static void Main(string[] args)
        {
            SDWeaponsManager w = SDWeaponsManager.GetInstace();
            if (args.Length == 2)
            {
                if (checkForPrime(args[0].Length))
                {
                    SDPistol p1 = new SDPistol();
                    w.AddWeapon(p1);
                }
                else
                {
                    SDPistol p1 = new SDPistol();
                    SDPistol p2 = new SDPistol();
                    w.AddWeapon(p1);
                    w.AddWeapon(p2);
                }

                if (checkForPrime(args[1].Length))
                {
                    SDMachineGun mg1 = new SDMachineGun();
                    SDMachineGun mg2 = new SDMachineGun();
                    w.AddWeapon(mg1);
                    w.AddWeapon(mg2);
                }
                else
                {
                    SDMachineGun mg1 = new SDMachineGun();
                    w.AddWeapon(mg1);
                }

                List<Thread> threadList = new List<Thread>();

                for (int i = 0; i < w.weaponListSize; i++)
                {
                    SDWeapon weapon = w.GetWeapon(i);
                    if (weapon.name == "Pistol")
                    {
                        Thread t = new Thread(() => ShootFullForce(weapon, 300));
                        threadList.Add(t);
                    }
                    else
                    {
                        Thread t = new Thread(() => ShootFullForce(weapon, 500));
                        threadList.Add(t);
                    }
                }

                for (int i = 0; i < threadList.Count; i++)
                {
                    threadList[i].Start();
                    Thread.Sleep(5000);
                }
                for (int i = 0; i < threadList.Count; i++)
                {
                    threadList[i].Abort();
                }
            }
            else
            {
                Console.WriteLine("Wrong number of console parameters.");
            }
            Console.WriteLine("Press any key to close the app.");
            Console.ReadKey();
        }
        static bool checkForPrime(int n, int i = 2)
        {
            if (n <= 2)
                return (n == 2) ? true : false;
            if (n % i == 0)
                return false;
            if (i * i > n)
                return true;

            return checkForPrime(n, i + 1);
        }

        static void ShootFullForce(SDWeapon weapon, int pause)
        {
            SDWeaponsManager w = SDWeaponsManager.GetInstace();
            w.PrintText("Start shooting new weapon");

            while (true)
            {
                weapon.Shoot();
                Thread.Sleep(pause);
            }
        }
    }
}
