﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAdll
{
    /// <summary>
    /// Pieter-Jan, Ahenkona
    /// </summary>
    public class PAMachineGun : PAWeapon
    {
        private int burst;

        public PAMachineGun() : base("MachineGun", 100, "ratatata")
        {
            
            this.burst = 10;
        }
        public override void Shoot()
        {

            if (amunition > 10)
            {
                amunition = amunition - burst;
                PAWeaponsManager.PAPrintText(false, soundLevel);

            }
            else
            {
                PAWeaponsManager.PAPrintText(true, "CLICKCLICKCLICK");
                Reload();
            }
        }
    }
}
