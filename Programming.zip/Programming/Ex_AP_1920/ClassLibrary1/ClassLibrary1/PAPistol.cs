﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAdll
{
    /// <summary>
    /// Pieter-Jan, Ahenkona
    /// </summary>
    public class PAPistol : PAWeapon
    {
        public PAPistol() : base("Pistol", 12, "pang")
        {
            
        }

    }
}
