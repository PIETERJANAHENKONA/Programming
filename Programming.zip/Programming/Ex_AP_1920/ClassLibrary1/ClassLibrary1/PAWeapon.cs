﻿using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAdll
{
    /// <summary>
    /// Pieter-Jan, Ahenkona
    /// </summary>
    public class PAWeapon : IPAWeapon
    {
        protected string name;

        protected int amunition;
        protected int maxAmunition;
        protected string soundLevel;

        public PAWeapon(string name, int amunition, string soundLevel)
        {
            this.name = name;
            this.amunition = amunition;
            this.maxAmunition = amunition;
            this.soundLevel = soundLevel;
        }

        public string Name
        {
            get { return name; }
        }

        public void Reload()
        {
            Console.WriteLine("[Wizard]: "+ name + " RELOADING ...");
            this.amunition = this.maxAmunition;

        }

        public virtual void Shoot()
        {

            if (amunition > 0)
            {
                amunition--;
                PAWeaponsManager.PAPrintText(false, soundLevel);
            }
            else
            {
                PAWeaponsManager.PAPrintText(true, "");
                Reload();

            }

        }
    }
}
