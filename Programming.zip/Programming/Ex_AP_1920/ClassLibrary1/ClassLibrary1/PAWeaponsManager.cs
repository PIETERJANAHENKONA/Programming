﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAdll
{
    /// <summary>
    /// Pieter-Jan, Ahenkona
    /// </summary>
    public class PAWeaponsManager
    {
        private static readonly object _Lock = new object();
        private static readonly object _Lock2 = new object();

        private List<PAWeapon> weaponList = new List<PAWeapon>();

        private int LengthOfWeaponList;

        public int GetLengthOfWeaponList
        {
            get 
            { 
                return LengthOfWeaponList = weaponList.Count; 
            }
        }


        static private PAWeaponsManager weaponsManager;
        private PAWeaponsManager()
        {
            weaponList = new List<PAWeapon>();

        }

        public static PAWeaponsManager GetPAWeaponsManager
        {
            get
            {
                if (weaponsManager == null)
                {
                    lock (_Lock)
                    {
                        if (weaponsManager == null)
                        {
                            weaponsManager = new PAWeaponsManager();
                        }

                    }
                }
                return weaponsManager;
            }
        }

        
        public void PAAddWeapon(PAWeapon weapon)
        {
            weaponList.Add(weapon);


        }


        
        public static void PAPrintText(bool clipEmpty, string gunSound)
        {
            lock (_Lock2)
            {
                if (clipEmpty)
                {
                    Console.WriteLine("[Wizard]: CLICK");

                }
                else
                {
                    Console.WriteLine("[Wizard]: "+gunSound);
                }

            }
        }

        public PAWeapon GetWeapon(int index)
        {
            if (weaponList.Count > index)
            {
                return weaponList[index];

            }
            else
            {
                Console.WriteLine("[Wizard]: Hey the index you where looking for was not found");
                return null;
            }
        }
    }
}
