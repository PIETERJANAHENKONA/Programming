﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using ClassLibrary1;
using PAdll;

namespace Ex_AP_1920
{
    class Program
    {
        /// <summary>
        ///Pieter-Jan, Ahenkona
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            string name;
            string familyName;
            bool isPrime;
            List<Thread> myListOfThreads = new List<Thread>();


            //Pieter-Jan, Ahenkona
            Console.WriteLine("[Wizard]: Give me Your Name and family name like this: 'Name', 'Family Name'");
            Console.Write("[User]: ");

            string nameAndFamilyName = Console.ReadLine();

            if (nameAndFamilyName.Contains(", ") && nameAndFamilyName.Length > 6 ) // Dividing your full name with substring
            {
                name = nameAndFamilyName.Substring(0, nameAndFamilyName.IndexOf(','));
                familyName = nameAndFamilyName.Substring(nameAndFamilyName.IndexOf(" ")+1);
                Console.WriteLine("[Wizard]: Hey, {0} {1} :)", name, familyName);
                Console.WriteLine("[Wizard]: The length of your first name is: " + name.Length);

                isPrime = PrimeNumber(name.Length-1, name.Length);

                if (isPrime)//If Name Prime initialize 1 pistol
                {
                    Console.WriteLine("[Wizard]: {0} is a prime number",name.Length);

                    PAPistol pistol1 = new PAPistol();
                    PAWeaponsManager.GetPAWeaponsManager.PAAddWeapon(pistol1);
                                       

                }
                else //If Name not Prime initialize 2 pistols
                {
                    Console.WriteLine("[Wizard]: {0} is not a prime number", name.Length);

                    PAPistol pistol2 = new PAPistol();
                    PAPistol pistol3 = new PAPistol();
                    PAWeaponsManager.GetPAWeaponsManager.PAAddWeapon(pistol2);
                    PAWeaponsManager.GetPAWeaponsManager.PAAddWeapon(pistol3);

                }

                Console.WriteLine("[Wizard]: The length of your Last name is: " + familyName.Length);

                isPrime = PrimeNumber(familyName.Length-1, name.Length);

                if (isPrime) //If Family name Prime initialize 2 MachineGun
                {
                    Console.WriteLine("[Wizard]: {0} is a prime number", familyName.Length);
                    PAMachineGun machineGun1 = new PAMachineGun();
                    PAMachineGun machineGun2 = new PAMachineGun();
                    PAWeaponsManager.GetPAWeaponsManager.PAAddWeapon(machineGun1);
                    PAWeaponsManager.GetPAWeaponsManager.PAAddWeapon(machineGun2);

                }
                else //If Family name Prime initialize 1 MachineGun
                {
                    Console.WriteLine("[Wizard]: {0} is not a prime number", familyName.Length);
                    PAMachineGun machineGun3 = new PAMachineGun();
                    PAWeaponsManager.GetPAWeaponsManager.PAAddWeapon(machineGun3);

                }
                for (int i = 0; i < PAWeaponsManager.GetPAWeaponsManager.GetLengthOfWeaponList; i++) //Add the list of weapons to List of Threads and start  
                {
                    if (PAWeaponsManager.GetPAWeaponsManager.GetWeapon(i).Name == "Pistol")
                    {
                        Thread newThread = new Thread(() => ShootFullForce(PAWeaponsManager.GetPAWeaponsManager.GetWeapon(i), 300));
                        myListOfThreads.Add(newThread);
                        newThread.Start();
                        Thread.Sleep(5000);

                    }
                    else
                    {
                        Thread newThread = new Thread(() => ShootFullForce(PAWeaponsManager.GetPAWeaponsManager.GetWeapon(i), 500));
                        myListOfThreads.Add(newThread);
                        newThread.Start();
                        Thread.Sleep(5000);

                    }

                }              
                foreach (Thread newThread in myListOfThreads)// abort all threads
                {
                    newThread.Abort();
                }

                Console.WriteLine("[Wizard]: Computation has ended");
                Console.WriteLine("[Wizard]: I'm closing the program");
                Console.Write("[Wizard]: Press any key to continue...");
                Console.ReadKey();

            }
            else
            {
                Console.WriteLine("[Wizard]: Wrong user input!");
            }



        }
        static bool PrimeNumber(int myNum, int myMaxNum)
        {

            if (myNum == 1)
            {
                return true;
            }
            else
            {

                int temp = myMaxNum % myNum;

                if (temp >= 1)
                {

                    return PrimeNumber(myNum - 1, myMaxNum);

                }
                else
                {
                    return false;
                }
            }
        }

        static void ShootFullForce(PAWeapon myWeapon, int pauzeWeapon)
        {
            
            bool dontstopShooting = true;

            Console.WriteLine("[Wizard]: Start shooting new weapon");
            do
            {
                myWeapon.Shoot();
                Thread.Sleep(pauzeWeapon);

               
            } while (dontstopShooting);
        }

    }
}
