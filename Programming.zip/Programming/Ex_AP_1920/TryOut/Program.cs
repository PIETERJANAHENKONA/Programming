﻿using System;

namespace TryOut
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int myInt = 7;
            int temp;
            temp = myInt;

            Console.WriteLine(6 % 5);

            Console.WriteLine(PrimeNumber(10, 11));
            string name;
            string familyName;
            Console.WriteLine("[Wizard]: Give me Your Name and family name like this: 'Name', 'Family Name'");

            string nameAndFamilyName = Console.ReadLine();

            if (nameAndFamilyName.Contains(", ") && nameAndFamilyName.Length > 6)
            {
                name = nameAndFamilyName.Substring(0, nameAndFamilyName.IndexOf(','));
                familyName = nameAndFamilyName.Substring(nameAndFamilyName.IndexOf(" ") + 1);

                Console.WriteLine("[Wizard]: Hey, {0} {1} :)",name ,familyName);


            }

        }
            static bool PrimeNumber(int myNum, int myMaxNum)
        {

            if (myNum == 1)
            {
                return true;
            }
            else
            {

                int temp = myMaxNum % myNum;

                if (temp >= 1)
                {

                    return PrimeNumber(myNum - 1, myMaxNum);

                }
                else
                {
                    return false;
                }
            }
        }
    }
}
