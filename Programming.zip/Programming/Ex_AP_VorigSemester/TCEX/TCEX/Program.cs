﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCdll;
using System.Threading;
using System.Diagnostics;

namespace TCEX
{
    class Program
    {
        //Tibo Claes
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("Wrong input: you need to add 2 console arguments");
            }
            else
            {
                Thread tcThread1 = new Thread(() => TCPrintMultiply(args[0]));
                tcThread1.Start();
                Thread tcThread2 = new Thread(() => TCPrintDivide(args[1]));
                tcThread2.Start();
            }
            Thread.Sleep(10002);
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        public static void TCPrintMultiply(string text)
        {
            TCColorText tcText = new TCColorText(text, ConsoleColor.Green);
            int tcCounter = 1;
            var tcSw = Stopwatch.StartNew();
            do
            {
                TCWriter.TCGetInstance().TCWriteColor(tcText.TCMultiply("student", tcCounter), tcText.tcShowcolor);
                tcCounter++;
                if (tcCounter==5)
                {
                    Thread.Sleep(200);
                    tcCounter = 1;
                }
            } while (tcSw.ElapsedMilliseconds<=10000);
            tcSw.Stop();
        }
        public static void TCPrintDivide(string text)
        {
            TCText tcText = new TCText(text);
            int tcCounter = 4;
            var tcSw2 = Stopwatch.StartNew();
            do
            {
                TCWriter.TCGetInstance().TCWrite(tcText.TCDivide(tcCounter));
                tcCounter--;
                if (tcCounter==1)
                {
                    Thread.Sleep(200);
                    tcCounter = 4;
                }
            } while (tcSw2.ElapsedMilliseconds<=10000);
            tcSw2.Stop();
        }
    }
}
