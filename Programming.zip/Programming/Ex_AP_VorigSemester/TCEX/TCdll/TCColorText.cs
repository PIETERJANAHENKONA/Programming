﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCdll
{
    //Tibo Claes
    public class TCColorText:TCText
    {
        ConsoleColor tcColor;
        public ConsoleColor tcShowcolor
        {
            get
            {
                return tcColor;
            }
        }

        public TCColorText(string input, ConsoleColor color):base(input)
        {
            tcColor = color;
        }
        public override string TCMultiply(string text, int repeat)
        {
            string output=text;
            for (int i = 0; i < repeat; i++)
            {
                output += text;
            }
            return base.TCMultiply(text, repeat);
        }
    }
}
