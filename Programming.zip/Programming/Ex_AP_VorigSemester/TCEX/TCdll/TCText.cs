﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCdll
{
    //Tibo Claes
    public class TCText:IDivideableTC,IMultiplyableTC
    {
        string tcText;
        public TCText(string input)
        {
            tcText = input;
        }
        public virtual string TCMultiply(string text, int repeat)
        {
            string output=text;
            for (int i = 0; i < repeat; i++)
            {
                output += tcText;
            }
            return output;
        }
        public string TCDivide(int number)
        {
            if (tcText.Length<=1)
            {
                return tcText;
            }
            else
            {
                return tcText.Substring(0, number);
            }
        }
    }
}
