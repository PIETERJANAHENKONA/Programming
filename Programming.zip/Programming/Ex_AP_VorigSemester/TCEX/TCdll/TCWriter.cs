﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCdll
{
    //Tibo Claes
    public class TCWriter
    {
        private static TCWriter tcInstance;
        private static object tcSafetylock = new object();
        private static object tcConsoleLock = new object();

        public TCWriter() { }
        public static TCWriter TCGetInstance()
        {
            if (tcInstance==null)
            {
                lock (tcSafetylock)
                {
                    if (tcInstance == null)
                    {
                        tcInstance = new TCWriter();
                    }
                }
            }
            return tcInstance;
        }
        public void TCWrite(string text)
        {
            lock (tcSafetylock)
            {
                Console.WriteLine(text);
            }
        }
        public void TCWriteColor(string text, ConsoleColor color)
        {
            lock (tcSafetylock)
            {
                ConsoleColor tcOriginal = Console.ForegroundColor;
                Console.ForegroundColor = color;
                Console.WriteLine(text);
                Console.ForegroundColor = tcOriginal;
            }
        }
    }
}
