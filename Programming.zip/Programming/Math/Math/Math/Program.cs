﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Math1
{
    enum wizard
    {
        No,
        Yes,
        Complicated

    }
    class Program
    {
        static void Main(string[] args)
        {
            Random dice = new Random();
            int numEyes = dice.Next(0,3);
            string anwser= null;
            string anwser2 = null;

            wizard answerWizard = wizard.No;


            Console.WriteLine("Ceiling: "+ Math.Ceiling(15.3));
            Console.WriteLine("Floor: "+ Math.Floor(15.3));

            double num1 = 13.8565;
            Console.WriteLine("Rounded: " + Math.Round(num1, 2));
            Console.WriteLine("Number of eyes: " + numEyes);

            Console.ReadKey();
            
            Console.WriteLine("User: Will I ever find true love?");

            switch (numEyes)
            {
                case 0:
                    anwser = "No...";
                    answerWizard = wizard.No;
                    break;
                case 1:
                    anwser = "It's complicated";
                    answerWizard = wizard.Complicated;
                    break;
                case 2:
                    anwser = "Yes you will!";
                    answerWizard = wizard.Yes;
                    break;
              
            }

            Console.WriteLine("Wizard says: "+ anwser);

            switch (answerWizard)
            {
                case wizard.No:
                    anwser2 = "You will never find 'LOVE'";
                    break;
                case wizard.Yes:
                    anwser2 = "You will find her";
                    break;
                case wizard.Complicated:
                    anwser2 = "It's not up to me to decide what 'TRUE LOVE' is";
                    break;
                default:
                    break;
            }
            Console.WriteLine("Wizard says: " + anwser2);
            Console.ReadKey();


        }
    }
}
