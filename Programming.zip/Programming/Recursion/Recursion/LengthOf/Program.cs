﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LengthOf
{
    class Program
    {
        /// <summary>
        /// Suppose a function that calculates the length of a string
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("[Wizard]: Give me a string and I will calculate it's length using recursion.");
            Thread.Sleep(750);
            Console.Write("[User]: ");
            string userString = Console.ReadLine();
            int temp = 0;
            Console.WriteLine("[Wizard]: The length of your string is {0}.", GetLengthString(userString));
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: This program will close.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();

        }  
        static int GetLengthString(string myString)
        {
            int curentLength;
            if (myString == null|| myString.Equals(""))
            {
                
                return  0;
            }
            else
            {
                curentLength = GetLengthString(myString.Substring(1)) + 1;
                return curentLength;

            }
        }
    }
}
