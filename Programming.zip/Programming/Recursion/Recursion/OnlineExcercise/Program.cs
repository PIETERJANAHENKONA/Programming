﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OnlineExcercise
{
    class Program
    {
        /// <summary>
        /// 4 maand is equivalent aan 1 paar;
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("[Wizard]: This program will write for you a Fibonacci sequence of a determined length recursively.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Give me the length of the sequence.");
            Thread.Sleep(750);


            Console.Write("[User]: ");
            string MonthsPassed = Console.ReadLine();

            if (int.TryParse(MonthsPassed, out int lengthOfSequenceInt))
            {

                Console.WriteLine("\n[Wizard]: {0}", AmountOfRabbits(lengthOfSequenceInt));

            }
            else
            {
                Console.WriteLine("[Wizard]:{0} is not an integer.",MonthsPassed);

            }
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: This program will close.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();

        }
        static int AmountOfRabbits(int myMonthsToPass)
        {
           
            if (myMonthsToPass < 2)
            {
                return myMonthsToPass;
            }
            else 
            {
                int temp1 = AmountOfRabbits(myMonthsToPass - 1);
                int temp2 = AmountOfRabbits(myMonthsToPass - 2);

                return  temp1 + temp2 ;
            }


        }

    }
}
