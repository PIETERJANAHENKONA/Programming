﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            int startOfCount;
            Console.WriteLine("[Wizard]: Give me a string and I will check if it is a palindrome or not.");
            Console.Write("[User]: ");
            string stringToCheck = Console.ReadLine();
            int stringLength = stringToCheck.Length;
            stringLength--;
            startOfCount = stringLength;

            if (IsPalindrome(stringToCheck, stringLength, ref startOfCount))
            {
                Console.WriteLine("[Wizard]: Your string is a palindrome");

            }
            else
            {
                Console.WriteLine("[Wizard]: Your string is not a palindrome");

            }
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: This program will close.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();


        }
        static bool IsPalindrome(string myStringToCheck, int myStringLength, ref int myStartOfCount)
        {

            if (myStringLength == 0)
            {
                return myStringToCheck[0] == myStringToCheck[myStartOfCount];
            }
            else
            {
                bool temp = IsPalindrome(myStringToCheck, myStringLength - 1, ref myStartOfCount);
                myStartOfCount = myStartOfCount - 1;


                if (temp == false)
                {
                    return false;
                }

                if (myStartOfCount == myStringLength)
                {
                    return true;
                }
                return myStringToCheck[myStartOfCount] == myStringToCheck[myStringLength];

            }
        }
    }
}
