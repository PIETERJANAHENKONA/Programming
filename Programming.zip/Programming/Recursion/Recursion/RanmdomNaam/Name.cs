﻿namespace RanmdomNaam
{
    class Name
    {
        private int MyProperty;
        /// <summary>
        /// Maak een klasse Naam die een string
        //bevat
        //❑ Genereer in de constructor recursief een
        //randomnaam op basis van random
        //karakters. Gebruik hiervoor een
        //hulpmethode GenerateName. De lengte
        //geef je mee als parameter aan de
        //constructor en de method.
        //❑ Genereer in je main een array van 10
        //Naam objecten. Vul deze array in in een
        //recursieve initialize methode. 

        /// </summary>
        public Name(int length)
        {
            

        }


        static string GenerateName(int length)
        {


        }
    }
}
