﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RanmdomNaam
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            object[] arrayOfNames = new object[10];

            char myChar = 

            
        }

    }
}
