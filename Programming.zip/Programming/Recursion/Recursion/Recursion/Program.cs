﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    class Program
    {
        static void Main(string[] args)
        {
            int factorial = 5;
            Console.WriteLine("[Wizard]: The factorial of {0} is {1}.", factorial, FactorialOfInt(factorial));

        }
        static int FactorialOfInt(int myFactorial)
        {
            if (myFactorial == 1)
            {
                return myFactorial;
            }
            else
            {
                return myFactorial* FactorialOfInt(myFactorial-1);
            }
        }
    }
}
