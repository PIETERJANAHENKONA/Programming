﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RecursionPower
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("[Wizard]: Give me an integer to power.");
            Console.Write("[User]: ");
            double.TryParse(Console.ReadLine(), out double userDouble);

            Console.WriteLine("[Wizard]: Give me the power.");
            Console.Write("[User]: ");
            double.TryParse(Console.ReadLine(), out double userPower);

            Console.WriteLine("[Wizard]: According to the Math class {0} to the power of {1} is {2}. ", userDouble,userPower, Math.Pow(userDouble,userPower));

            Console.WriteLine("[Wizard]: According to the recursive function {0} to the power of {1} is {2}.", userDouble, userPower, GetPowerOf(userPower,userDouble));


            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: This program will close.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();

        }
        static double GetPowerOf(double myPower, double myDouble)
        {
            if (myPower == 0)
            {
                return 1;
            }
            else
            {
                ;

                return myDouble * GetPowerOf(myPower - 1, myDouble);
            }
            
        }
    }
}
