﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ReverseString
{
    class Program
    {
        /// <summary>
        /// //Opdracht
        //❑ Wat is de stop of base case om een
        //string achterwaarts uit te schrijven
        //❑ Wat is de recursieve rekenmethode?
        //❑ Schrijf een console applicatie die
        //– Een string als invoer vraagt
        //– De omgekeerde string als uitvoer geeft

        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("[Wizard]: Give me a string and I will print it reversed using recursion.");
            Console.Write("[User]: ");
            string toReverse = Console.ReadLine();
            int lengthOfString = toReverse.Length;
            lengthOfString--;

            Console.WriteLine("[Wizard]: {0}.", GetReverse(toReverse, lengthOfString));

            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: This program will close.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();


        }
        static string GetReverse(string myStringToReverse, int  myLengthOfString) 
        {
            if (myLengthOfString == 0)
            {
                return myStringToReverse[0].ToString();
            }
            else
            {

                string temp = myStringToReverse[myLengthOfString].ToString();

                return String.Concat(temp, GetReverse(myStringToReverse,(myLengthOfString-1)));
            }
        }
    }
}
