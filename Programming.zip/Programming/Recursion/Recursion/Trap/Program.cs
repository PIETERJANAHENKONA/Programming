﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Trap
{
    class Program
    {
        /// <summary>
        /// //❑ Gegeven een trap met N treden.
        //– wannneer men 1 of 2 treden tegelijk kan doen en ook
        //alle mogelijke combinaties hiervan.
        //– Op hoeveel verschillende manieren kan men deze trap
        //oplopen
        //– Wat als je na 2 treden ineens, enkel maar 1 trede mag
        //nemen?
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int stairs = 4;

            Console.WriteLine("[Wizard]: "+combinationsToWalkUpTheStairs(stairs));
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: This program will close.");
            Thread.Sleep(750);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();
        }
        static int combinationsToWalkUpTheStairs(int myStairs)
        {
            if (myStairs < 2)
            {
                return 1;
            }
            else
            {
                return combinationsToWalkUpTheStairs(myStairs - 1) + combinationsToWalkUpTheStairs(myStairs-2);
            }
        }

    }
}
