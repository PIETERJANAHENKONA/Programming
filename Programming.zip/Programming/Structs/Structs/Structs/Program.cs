﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structs
{
    struct Game
    {
        // No constructors 
        public string name;
        public string developer;
        public int rating;
        public string releaseDate;

    }

    
    class Program
    {
        enum Weekday
        {
            Mo,
            Tu,
            We,
            Th,
            Fr,
           
        }
      
        
        static void Main(string[] args)
        {
            Game myGame;

            myGame.developer = "PJ";
            myGame.rating = 3;
            myGame.releaseDate = "02.07.2021";
            myGame.name = "KillSteve";

            Weekday day = Weekday.Mo;
            Console.WriteLine("Today is "+day.ToString()+" "+day);
            Console.WriteLine("Today is " + day.ToString() + " " + day);

            Console.ReadKey();


        }
    }
}
