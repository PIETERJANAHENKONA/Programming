﻿using System;
using System.IO;


namespace Textfile
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Life is misery");
            string lyrics = "A Dream lyrics\n2Pac\n[Intro]\nIt was all a dream\n\n[Refrain: Faith Evans]\nLast night I had a dream, thoughts was racing through my head\nFelt so real to me, this is what was said";

            try
            {
                using (StreamWriter newTextFile = new StreamWriter(@"G:\2021\Programming\Textfile\Textfile\Textfile\NewText1.txt"))
                newTextFile.WriteLine(lyrics);
            }
            catch (Exception)
            {
                Console.WriteLine("That did not work");
            }
            Console.ReadKey();



        }
    }
}
