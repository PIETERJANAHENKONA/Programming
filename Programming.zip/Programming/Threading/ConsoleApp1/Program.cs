﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            new Thread(Go).Start(3);

            Thread t = new Thread(Go);
            t.Start(3);

        }

        static void Go(object b)
        {
            // Declare and use a local variable - 'cycles' 
            for (int cycles = 0; cycles < 5; cycles++) Console.Write('?');
        }
    }
}
