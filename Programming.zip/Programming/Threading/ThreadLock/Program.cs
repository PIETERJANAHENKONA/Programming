﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadLock
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Thread thread1 = new Thread(ThreadSafe.Go);
            Thread thread2 = new Thread(ThreadSafe.Go);

            thread1.Start();
            thread2.Start();

        }
    }
}
