﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadOefening
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread thread1 = new Thread(PrintGhost);
            thread1.Name = "Thread1";
            Thread.CurrentThread.Name = "MainThread";
            thread1.Start();

            for (int i = 0; i < 50; i++)
            {
                Console.Write(" E ");
                Thread.Sleep(100);
            }

            thread1.Join();

            Console.WriteLine();
            Console.WriteLine("Thread \"" + thread1.Name + "\" Has ended.");

            Console.WriteLine("Thread \"" + Thread.CurrentThread.Name + "\" Has ended.");


        }
        static void PrintGhost()
        {
            for (int i = 0; i < 20; i++)
            {
                Console.Write(" GHOST ");
                Thread.Sleep(50);
            }
        }
    }
}
