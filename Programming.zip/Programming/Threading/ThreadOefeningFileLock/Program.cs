﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace ThreadOefeningFileLock
{
    class Program
    {
        /// <summary>
        /// Maak een programma dat een tekstfile regel per regel inleest
        /// Maak een thread die tekst naar een andere file regel per regel kopieertVraag aan de gebruiker de 2 filenames
        /// Lees de ene file in en kopieer daarna naar de 2e file
        /// Zorg dat er tijdens de eerste thread een balkje volloop en tijdens de tweede thread een percentage wordt getoond
        /// Test best met een vrij grote tekstfile zodat het niet te snel loopt, 
        /// voor kleinere files kan je ook met Sleep werken om te vertragen
        /// </summary>
        /// <param name="args"></param>

        private static readonly object _lock = new object();
        
        static void Main(string[] args)
        {
            string[] linesOfLyrics;
            int amountOfLines;

            Console.WriteLine("[Wizard]: Hey, I am the Wizard.");
            Console.WriteLine("[Wizard]: I Will read from a .textfile (from.txt) to another (to.txt).");

            Console.WriteLine("[Wizard]: Lets first get the amount of lines in your text.");
            Console.WriteLine("[Wizard]: ...");
            amountOfLines = GetTextLength();
            linesOfLyrics = new string[amountOfLines];
            Console.WriteLine("[Wizard]: This lyric sheet is {0} lines long.", amountOfLines);

            ReadFromText(amountOfLines, ref linesOfLyrics);

            Console.WriteLine("[Wizard]: This is the text that was read: ");
            Console.WriteLine();
            foreach (string line in linesOfLyrics)
            {
                Console.WriteLine(line);
            }

            Console.WriteLine();
            Console.WriteLine("[Wizard]: Now lets write the array of lines to a different file.");


            Thread writerThread = new Thread(()=> WriteToText(amountOfLines, linesOfLyrics));

            writerThread.Start();

            Console.WriteLine("[Wizard]: Check the to.txt file in file explorer to confirm if the procedure has succeeded.");
            Console.WriteLine("[Wizard]: Press any key to continue...");
            Console.ReadKey();



        }
        static int GetTextLength()
        {
            return File.ReadAllLines("from.txt").Length;// Gets the amount lines in the text-file.
        }
        static void WriteToText(int  myAmountOfLines,  string[] myLinesOfLyrics)
        {
            StreamWriter writer = null;

            lock (_lock)
            {
                try
                {
                    writer = new StreamWriter("to.txt");

                    for (int i = 0; i < myAmountOfLines; i++)
                    {
                        writer.WriteLine(myLinesOfLyrics[i]);
                        Console.WriteLine("[Wizard]: Line {0} are written!",i+1);


                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("[Wizard]: Writing procedure has failed!");

                }
                finally
                {
                    writer.Close();
                    Console.WriteLine("[Wizard]: All Lines are written!");

                }
            }
           

        }
        static void ReadFromText( int myAmountOfLines, ref string[] myLinesOfLyrics)
        {
            
            lock (_lock)
            {
                StreamReader reader = null; 
                try
                {
                    reader = new StreamReader("from.txt");

                    for (int i = 0; i < myAmountOfLines; i++)
                    {
                       myLinesOfLyrics[i] = reader.ReadLine();


                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("[Wizard]: Reading procedure has failed!");
                }
                finally
                {
                    if (reader != null) //if file was open (if opening failed reader==null)
                    {
                        reader.Close(); //if file was opened successfully
                        Console.WriteLine("[Wizard]: All Lines where read!");

                    }
                }
            }
           

        }
    }

}
