﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace ThreadOefeningWriteLock
{
    /// <summary>
//    /// Schrijf 2 methodes die elk met minstens 3 
//    writes iets naar de console schrijven
//❑ Laat ze dit beide 100x uitvoeren, in aparte
//threads, gelijktijdig
//❑ Wat gebeurt er met de output?
//❑ Los dit probleem proper op! Zorg er wel
//voor dat ze nog simultaan output kunnen
//voorzien(dus niet eerst de ene, dan de
//andere 100x)
    /// </summary>
    class Program
    {
        private static readonly object _Lock = new object();
        private static readonly object _Lock2 = new object();
        static void Main(string[] args)
        {
            Thread abc = new Thread(() =>
            {
                WriteToFile();
                WriteToFile2();

            }); 
            Thread def = new Thread(() =>
            {
                WriteToFile();
                WriteToFile2();

            });

            abc.Start();
            def.Start();
        }
        static void WriteToFile()
        {
            lock (_Lock2)
            {

                for (int i = 0; i < 100; i++)
                    {
                        Console.Write("A");
                        Console.Write("B");
                        Console.Write("C");
                    }

        }


    } 
        static void WriteToFile2()
        {
            lock (_Lock)
            {

                for (int i = 0; i < 100; i++)
                    {
                        Console.Write("D");
                        Console.Write("E");
                        Console.Write("F");
                    }

            }

        }


    }
}
