﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace IsAliveJoin
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Console.WriteLine("Main thread has started");
            Thread myThread1 = new Thread(ThreadFunction1);
            Thread myThread2 = new Thread(ThreadFunction2);

            myThread1.Start();
            myThread1.Join(5000);// voert eerst alle threads uit tot op deze lijn code binnen 5 seconden

            myThread2.Start();
            myThread2.Join();

            for (int i = 0; i < 100; i++)
            {
                Console.Write(2);
                Thread.Sleep(500);
            }

            Console.WriteLine("Main thread has ended");


        }
        public static void ThreadFunction1()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.Write(0);
                Thread.Sleep(500);

            }
        }
        public static void ThreadFunction2()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.Write(1);
                Thread.Sleep(500);

            }
        }
    }
}
