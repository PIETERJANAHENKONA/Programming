﻿using System;
using System.Threading;

namespace Threading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Fuck you");
            Thread.Sleep(2000);
            Console.WriteLine("Bitch");
            Thread.Sleep(2000);

            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine($"Thread 1: met thread ID: {Thread.CurrentThread.ManagedThreadId}");
            }).Start();


            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine($"Thread 2: met thread ID: {Thread.CurrentThread.ManagedThreadId}");
            }).Start();

            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine($"Thread 3: met thread ID: {Thread.CurrentThread.ManagedThreadId}");
            }).Start();


            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine($"Thread 4: met thread ID: {Thread.CurrentThread.ManagedThreadId}");
            }).Start();

            Console.ReadKey();

        }
    }
}
