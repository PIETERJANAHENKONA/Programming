﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace ThreadingLatExcersice
{
    class Program
    {
        /// <summary>
        /// //Maak een methode AddUpTo, die getallen
        //optelt van 0 tot een bepaald getal
        //❑ Over deze methode uit voor getallen van 0
        //tot 100 en reken uit hoelang deze methode
        //er telkens over doet om dit uit te rekenen
        //❑ Bereken de gemiddelde tijd dat AddUpTo
        //nodig heeft voor een berekening
        //(gemiddelde tijd over alle 100 uitvoeringen)

        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            bool keepCalculating = true;
            string closeTheProgram;
            bool wrongUserInput = true;
            do
            {

                Console.WriteLine("[Wizard]: This program will increment an integer to a target integer.");
                Thread.Sleep(750);
                Console.WriteLine("[Wizard]: It will then print the time elapsed to finish the calculation.");
                Thread.Sleep(750);
                Console.WriteLine("[Wizard]: Give me a starting integer greater or equal to 0.");
                Thread.Sleep(750);
                Console.Write("[User]: ");
                bool failedParse = int.TryParse(Console.ReadLine(), out int startingNumber);

                if (failedParse)
                {
                    Console.WriteLine("[Wizard]: Give me the integer you wish to increment {0} to.", startingNumber);
                    Console.Write("[User]: ");
                    failedParse = int.TryParse(Console.ReadLine(), out int goalNumber);
                    if (failedParse)
                    {
                        Console.WriteLine("[Wizard]: Your request will now be processed.");
                        AddUpTo(startingNumber, goalNumber);

                        do
                        {
                            Console.WriteLine("[Wizard]: Would you like to try again? [y/n]");
                            Console.Write("[User]: ");
                            closeTheProgram = Console.ReadLine();

                            if (closeTheProgram == "y")
                            {
                                keepCalculating = true;
                                wrongUserInput = false;

                            }
                            else if (closeTheProgram == "n")
                            {
                                Console.WriteLine("[Wizard]: This program has ended.");

                                keepCalculating = false;
                                wrongUserInput = false;

                            }
                            else
                            {
                                PrintFailedInput();
                                wrongUserInput = true;

                            }
                        } while (wrongUserInput);

                    }
                    else
                    {
                        PrintFailedInput();

                    }

                }
                else
                {
                    PrintFailedInput();
                }

            } while (keepCalculating);
            Console.WriteLine("[Wizard]: Press any key to continue ...");
            Console.ReadKey();
        }

        static void PrintFailedInput()
        {
            Console.WriteLine("[Wizard]: You failed to give the right input! try again...");
        }
        static void AddUpTo(int myStartingNumber, int myGoalNumber)
        {
            Stopwatch myWatch;
            TimeSpan totalTimeElapsed = TimeSpan.Zero;

            if (0 <= myStartingNumber && 0 <= myGoalNumber && myStartingNumber < myGoalNumber)
            {


                myWatch = new Stopwatch();
                myWatch.Start();


                int totalToAdd = myGoalNumber - myStartingNumber;
                for (int i = 0; i < totalToAdd; i++)
                {
                    myStartingNumber++;
                    Console.WriteLine("[Wizard]: ...");
                    Thread.Sleep(100);

                }
                myWatch.Stop();
                totalTimeElapsed = myWatch.Elapsed;
                Console.WriteLine("[Wizard]: It took {0} seconds to complete this method.", totalTimeElapsed.TotalSeconds);

            }
            else
            {
                Console.WriteLine("[Wizard]: Wrong user input!");
                Thread.Sleep(100);
                Console.WriteLine("[Wizard]: Try again...");

            }
        }
    }
}
