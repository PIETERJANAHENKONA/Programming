﻿using System;
using System.Threading;

namespace ThreadingParameters
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] myMomNames = new string[5]
                           {
                    "Samantha","Sarah","Stephanie","Jennifer","Elizabeth"
                           };

            Thread thread = new Thread(() => PrintMom(myMomNames));// Adding parameters to a thread from the main thread
            thread.Start();

            new Thread(() => {
                Thread.CurrentThread.Name = "unnamedThread";
                string threadIsAlive;
              
                for (int i = 0; i < 30; i++)
                {
                    if (Thread.CurrentThread.IsAlive)
                    {
                        threadIsAlive = " Is alive .";
                    }
                    else
                    {
                        threadIsAlive = " Is not alive anymore .";

                    }
                    Console.WriteLine("Thread "+Thread.CurrentThread.Name+threadIsAlive);
                }
            }).Start();


        }
        static void PrintMom(string[] momNames)
        {
            Random newRandomMom = new Random();

            for (int i = 0; i < 60; i++)
            {
                int myMomInt = newRandomMom.Next(0, 5);
                Console.WriteLine(momNames[myMomInt]);
            }
        }
    }
}
